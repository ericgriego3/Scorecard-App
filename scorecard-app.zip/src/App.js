import { useState } from "react";

const initialMetrics = {
  "Speeding": "",
  "Seatbelts": "",
  "Sign/Signal": "",
  "Distraction": "",
  "Following Distance": "",
  "Delivery Completion Rate": "",
  "Photo on Delivery": "",
  "Delivery Success Behaviours": "",
  "CDF": "",
  "Customer Escalation Defect": "",
  "High Performer Share": "",
  "Low Performer Share": "",
  "Tenured Workforce": "",
};

const config = {
  "Speeding": [10.4, 0.036, "raw"],
  "Seatbelts": [10.4, 0.065, "raw"],
  "Sign/Signal": [10.4, 0.04, "raw"],
  "Distraction": [6.7, 0.0959, "raw"],
  "Following Distance": [4.5, 0.0959, "raw"],
  "Delivery Completion Rate": [10, 0.3466, "%"],
  "Photo on Delivery": [2.5, 0.3466, "%"],
  "Delivery Success Behaviours": [10, 0.001037, "raw"],
  "CDF": [6.7, 0.000240, "raw"],
  "Customer Escalation Defect": [13.3, 0.0005, "raw"],
  "High Performer Share": [5, 0.35, "%"],
  "Low Performer Share": [5, 0.35, "%"],
  "Tenured Workforce": [5, 0.2884, "%"],
};

function calculateScore(metric, maxScore, k, type) {
  const value = parseFloat(metric);
  if (isNaN(value)) return 0;
  const x = type === "%" ? 100 - value : value;
  return maxScore * Math.exp(-k * x);
}

export default function App() {
  const [metrics, setMetrics] = useState(initialMetrics);

  const totalScore = Object.entries(metrics).reduce((sum, [key, val]) => {
    const [max, k, type] = config[key];
    return sum + calculateScore(val, max, k, type);
  }, 0);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Scorecard Calculator App</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {Object.entries(metrics).map(([key, val]) => (
          <div key={key}>
            <label className="block font-medium mb-1">{key}</label>
            <input
              type="number"
              value={val}
              onChange={(e) =>
                setMetrics({ ...metrics, [key]: e.target.value })
              }
              placeholder="Enter metric value"
              className="w-full border rounded px-3 py-2"
            />
          </div>
        ))}
      </div>
      <div className="mt-6 text-2xl font-semibold">
        Total Score: {totalScore.toFixed(2)} / 100
      </div>
    </div>
  );
}
